package org.eclipse.jet.exception;

public interface WarnCode {

	public int getNumber();
	
}
