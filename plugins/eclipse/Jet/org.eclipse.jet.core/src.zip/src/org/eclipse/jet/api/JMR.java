package org.eclipse.jet.api;

public class JMR {

	public static String GROUP = "group";
	
	public static String MODEL = "model";
	
	public static String TASK_GROUP = "task_group";
	
	public static String TASK_MODEL = "task_model";
	
	public static String TASK_ACTION = "task_action";
	
	public static String TASK_TEMPLATE = "task_template";
	
	public static String TASK_DIRECTORY = "task_directory";
	
	public static String TASK_NAME = "task_name";
	
	public static String TASK_EXT = "task_ext";
	
	public static String TASK_ENCODING = "task_encoding";
	
	public static String TASK_MODE = "task_mode";
	
}
