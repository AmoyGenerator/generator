package org.eclipse.jet.exception;

public interface ErrorCode {
    
	public int getNumber();
	
}
